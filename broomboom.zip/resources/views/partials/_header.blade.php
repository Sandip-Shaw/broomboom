<script>(function (w, d, s, l, i) {
			w[l] = w[l] || []; w[l].push({
				'gtm.start':
					new Date().getTime(), event: 'gtm.js'
			}); var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
					'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-M7MG2W8');</script>
	<meta charset="utf-8" />
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />

	
	<meta content="detective agency name=" description" />
	<meta content="" name="keywords" />

	<style>
		.topbar {
			background: black;
		}

		.header {
			background: black;
		}
	</style>

	<link href="{{asset('assets/img/favicon.png')}}" rel="icon" />
	<link href="{{asset('assets/img/apple-touch-icon.png')}}" rel="apple-touch-icon" />

	<link href="{{asset('assets/vendor/animate.min.css')}}" rel="stylesheet" />
	<link href="{{asset('assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" />
	<link href="{{asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet" />

	<link href="{{asset('assets/css/main.css')}}" rel="stylesheet" />
	<link href="{{asset('assets/js/swiper/swiper-bundle.min.css')}}" rel="stylesheet" />
	<link href="{{asset('assets/vendor/aos/aos.css')}}" rel="stylesheet" />