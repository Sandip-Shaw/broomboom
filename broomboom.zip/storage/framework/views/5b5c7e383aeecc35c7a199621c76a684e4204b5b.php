<h1><?php echo e($otp); ?></h1>
<p>Please enter the OTP in the App to complete registration</p><?php /**PATH D:\xampp\htdocs\broomboom\resources\views/email/otp.blade.php ENDPATH**/ ?>